const age = 20;
age = 21;