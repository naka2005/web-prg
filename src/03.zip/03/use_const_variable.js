const age = 20;
console.log(age);