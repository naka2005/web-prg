let name = 'Alice';
let Name = 'Bob';
console.log(name);
console.log(Name);