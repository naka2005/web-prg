let price = 100;
console.log(price);
console.log('price');