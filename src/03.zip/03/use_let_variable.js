let price = 100;
console.log(price);

let name = 'Arice';
console.log(name);