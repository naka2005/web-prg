const elements = document.querySelectorAll(".sample");
for (const element of elements) {
    console.log(elements);
}
