const p = document.querySelector("p");

p.style.fontSize = "36px";
p.style.color = "red";
p.style.backgroundColor = "yellow";
