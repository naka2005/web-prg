const img = document.querySelector("img");
img.width = 300;
