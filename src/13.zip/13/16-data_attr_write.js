const profile = document.querySelector(".profile");
profile.CDATA_SECTION_NODE.id = 999;
profile.CDATA_SECTION_NODE.userName = "new zaru";
console.log(profile);
