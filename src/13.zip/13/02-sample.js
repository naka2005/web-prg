const tag = window.document.querySelector("#sample");
tag.textContent = "テキストを書き換えます";
