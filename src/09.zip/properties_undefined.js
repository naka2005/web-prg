const book = {title: '吾輩は猫である'}

console.log(book.author);
console.log(book['author']);