const book = {title: '吾輩は猫である'}

console.log(book.title);
console.log(book['title']);