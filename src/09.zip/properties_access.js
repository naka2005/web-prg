const book = {title: '吾輩は猫である'}
const a = 'title';
console.log(book[a]);
console.log(book.a);