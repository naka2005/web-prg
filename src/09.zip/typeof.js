const obj = {a: 1}
console.log(typeof obj);