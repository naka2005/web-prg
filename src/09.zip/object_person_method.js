const person = {
    name: 'アリス',
    greet: function() {
        console.log('こんにちは');
    }
}

person.greet();