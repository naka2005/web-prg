const book = {
    title: '吾輩は猫である',
    author: '夏目漱石',
    pages: 620
}

console.log(book);