function sample() {
    const x = 10;
    console.log(x);
}

sample();
console.log(x);
