function double(number) {
    const result = number * 2;
    return result;
}

const a = double(10);
console.log(a);

const b = double(8);
console.log(b);
