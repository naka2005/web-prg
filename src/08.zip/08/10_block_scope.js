if (true) {
    const x = 10;
    console.log(x);
}

console.log(x);
