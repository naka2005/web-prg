const age1 = 25;
if (age1 > 20 && age1 <= 29) {
    console.log("20代");
}

const age2 = 65;
if (age2 <= 10 || age2 >= 60) {
    console.log("ジュニアまたはシニア");
}
