const b = 10;
console.log(b < 4 || b < 9);
