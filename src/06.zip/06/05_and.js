const a = 5;

console.log(a > 1 && a < 9);
console.log(a > 1 && a < 3);
