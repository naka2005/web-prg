const fruits = ['りんご', 'みかん', 'バナナ', 'ぶどう'];

for(let i = 0; i < fruits.length; i++){
    console.log(fruits[i]);
}