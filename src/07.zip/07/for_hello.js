for (let i = 0; i < 10; i++) {
    console.log("hello");
}

for (let i = 5; i <= 10; i++) {
    console.log(i);
}
