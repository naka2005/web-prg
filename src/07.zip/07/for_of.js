const fruits = ['りんご', 'みかん', 'バナナ'];

for(const fruit of fruits){
    console.log(fruit);
}