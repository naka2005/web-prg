let number = 2;

while(number < 100){
    console.log(`${number}番`);
    number = number * 2;
}