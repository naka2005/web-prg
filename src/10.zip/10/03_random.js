console.log(Math.random());
console.log(Math.random());
console.log(Math.random());
