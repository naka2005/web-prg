console.log(Math.random() * 6 + 1);
