const theDay = new Date(2030, 3, 9, 5, 20, 0);

console.log(theDay.getFullYear());
console.log(theDay.getMonth());
console.log(theDay.getDate());
