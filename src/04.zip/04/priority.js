console.log(3 + 5 * 2);
console.log((3 + 5) * 2);