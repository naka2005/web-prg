const name = 'Alice';

const text1 = '私の名前は' + name + 'です';
console.log(text1);

const text2 = `私の名前は${name}です`; 
console.log(text2);
