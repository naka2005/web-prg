const a = '長い1行目の文章\n' +
    '長い2行目の文章\n' +
    '長い3行目の文章\n' ;
console.log(a);

const b = `長い1行目の文章
長い2行目の文章
長い3行目の文章`;

console.log(b);