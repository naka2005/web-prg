const a = 'Hello world';
console.log(a);

const b = 'こんにちは';
console.log(b);

console.log('Alice');
console.log('Bob');