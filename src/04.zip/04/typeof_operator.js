console.log(typeof 10);
console.log(typeof 'hello');