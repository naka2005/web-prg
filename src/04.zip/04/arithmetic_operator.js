console.log(1 + 2);
console.log(10%3);