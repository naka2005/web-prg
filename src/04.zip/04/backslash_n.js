const text2 = 'こんにちは\n私の名前はAliceです';
console.log(text2);