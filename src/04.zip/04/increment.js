let count = 10;
count++;
console.log(count);