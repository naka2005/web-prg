const a = 1;
const b = 2;
const c = '2';

console.log(a + b);
console.log(a + c);