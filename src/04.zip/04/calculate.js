console.log(10-3);
console.log(3*5);
console.log(10/4);
console.log(17%5);
console.log(2**4);