const name = 'Alice';
const text = '私の名前は' + name + 'です';
console.log(text);