console.log(1 + 2);

const total  = 1 + 2;
console.log(total);