let score;
score = 100;
console.log(score = 200);