const a = 1;
const b = 2;
console.log(a < b);
console.log( a >= 3);
console.log((a + b) > 3);