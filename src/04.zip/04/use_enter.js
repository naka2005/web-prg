const text1 ='こんにちは
私の名前はAliceです';