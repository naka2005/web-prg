const a = 'Java' + 'Script';
console.log(a);