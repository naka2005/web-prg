console.log('私の名前は\'Alice\'です');
console.log('私の名前は'Alice'です');