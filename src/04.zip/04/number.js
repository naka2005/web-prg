const x = 123;
console.log(x);

console.log(456);