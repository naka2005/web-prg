console.log(typeof 100);
console.log(typeof '100');