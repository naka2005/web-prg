console.log(Boolean(1));
console.log(Boolean(0));
console.log(Boolean('hello'));
console.log(Boolean(''));
console.log(Boolean(null));
console.log(Boolean(undefined));