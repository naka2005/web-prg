const interests = ['読書','料理','キャンプ'];
interests[0] = '散歩'
console.log(interests);