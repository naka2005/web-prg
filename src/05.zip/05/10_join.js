const interests = ['読書','料理','キャンプ'];
const a = interests.join('と')
console.log(a);