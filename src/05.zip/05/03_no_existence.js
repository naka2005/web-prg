const interests = ['読書','料理','キャンプ'];
const element5 = interests[5];
console.log(element5);