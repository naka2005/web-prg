const interests = ['読書','料理','キャンプ'];

console.log(interests);