const fruits = ['みかん','りんご','バナナ'];

const check1 = fruits.includes('りんご');
console.log(check1);

const check2 = fruits.includes('ぶどう');
console.log(check2);