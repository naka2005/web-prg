const string = '読書&料理&キャンプ';

const a = string.split('&');
console.log(a);