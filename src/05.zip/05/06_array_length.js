const interests = ['読書','料理','キャンプ'];
const count =interests.length;
console.log(count);