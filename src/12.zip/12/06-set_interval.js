function delayTask() {
    console.log("1秒ごとに繰り返し実行される");
}
setInterval(delayTask, 1000);
