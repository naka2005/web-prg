const newWindow = open("http://example.com");

newWindow.close();
