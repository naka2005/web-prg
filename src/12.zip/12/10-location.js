location.reload();

location.href = "https://www.google.co.jp/";
