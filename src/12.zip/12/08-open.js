open("https://example.com", "window name", "width=400,height=250");
